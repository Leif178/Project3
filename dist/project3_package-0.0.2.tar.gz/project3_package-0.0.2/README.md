Welcome to Project 3,

To install the project package use the command line:

python3 -m pip install --index-url https://test.pypi.org/simple/ --no-deps project3-package

There are no special dependencies.

To validate the code you can use the newly installed shell command JNP3, this command has no options but will start running the simulation, which first shows an example, then runs several more simulations to calculate the Gelman=-Rubin Statisitc.